from django.apps import AppConfig


class DrinksConfig(AppConfig):
    name = 'drinks'
