from django.contrib import admin
from .models import Drink
# Register your models here.

admin.site.register(Drink)

